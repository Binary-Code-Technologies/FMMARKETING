
<div class="footer" style="position:relative;">
    	<div class="footerleft">Chaaruvi Solutions</div>
    	<div class="footerright">&copy; <a href="www.trinitysolutions.in">www.chaaruvi.com</a></div>
    </div>