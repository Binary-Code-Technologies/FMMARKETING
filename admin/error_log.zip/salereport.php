<?php
//error_reporting(0);
include("../adminsession.php");
$pagename ="salereport.php"; 
$module = "Sale Report";
$submodule = "Sale Report List";
$btn_name = "Search";
$keyvalue =0 ;
$tblname = "saleentry";
$tblpkey = "saleid";
if(isset($_GET['saleid']))
$keyvalue = $_GET['saleid'];
else
$keyvalue = 0;
if(isset($_GET['action']))
$action = $_GET['action'];

$search_sql = "";

if($_GET['fromdate']!="" && $_GET['todate']!="")
{
	$fromdate = addslashes(trim($_GET['fromdate']));
	$todate = addslashes(trim($_GET['todate']));
}
else
{
	$fromdate = date('d-m-Y');
	$todate = date('d-m-Y');
}
$crit = " where 1 = 1 ";
if($fromdate!="" && $todate!="")
{
	$fromdate = $cmn->dateformatusa($fromdate);
	$todate = $cmn->dateformatusa($todate);
	$crit .= " and  saleentry.saledate between '$fromdate' and '$todate'";
}	

if(isset($_GET['suppartyid']))
{
	$suppartyid = trim(addslashes($_GET['suppartyid']));	
	
	if($suppartyid !='')  { $crit .=" and suppartyid='$suppartyid' ";$crit1 .=" and A.suppartyid='$suppartyid' "; }
}
else
{
	$suppartyid= '';
}

?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<?php include("inc/top_files.php"); ?>
</head>

<body>

<div class="mainwrapper">
	
    <!-- START OF LEFT PANEL -->
    <?php include("inc/left_menu.php"); ?>
    
    <!--mainleft-->
    <!-- END OF LEFT PANEL -->
    
    <!-- START OF RIGHT PANEL -->
    
   <div class="rightpanel">
    	<?php include("inc/header.php"); ?>
        
        <div class="maincontent">
        	<div class="contentinner">
              <?php include("../include/alerts.php"); ?>
            	<!--widgetcontent-->        
                <div class="widgetcontent  shadowed nopadding">
                    <form class="stdform stdform2" method="get" action="">
                    
                    <table id="mytable01" align="center" class="table table-bordered table-condensed"  >
                    <tr>
                    	
                        <th>From Date</th>
                        <th>To Date : </th>
                       <th width="15%">Customer </th>
                      
                    </tr>
                    <tr>
                    
              
                    
                     <td><input type="text" name="fromdate" id="fromdate" class="input-medium"  placeholder='dd-mm-yyyy'
                     value="<?php echo $cmn->dateformatindia($fromdate); ?>" data-inputmask="'alias': 'dd-mm-yyyy'" data-mask /> </td>
                   
                    
                    <td><input type="text" name="todate" id="todate" class="input-medium" 
                    placeholder='dd-mm-yyyy' value="<?php echo $cmn->dateformatindia($todate); ?>" data-inputmask="'alias': 'dd-mm-yyyy'" data-mask /></td>
                     <td>
                    
                       <select id="suppartyid" name="suppartyid" class="form-control chzn-select" style="width:180px;">
                    <option value="">-select-</option>
                    <?php     
						    	    $sql = mysqli_query($connection,"select * from  m_supplier_party where type_supparty='party' order by supparty_name ") ;
                            while($row= mysqli_fetch_assoc($sql))
                            {
                            ?>
                                        <option value="<?php echo $row['suppartyid'];?>"><?php echo $row['supparty_name'];?></option>
                                          <?php 
                            }
                            ?>
                   </select>
                                    
                                  <script> document.getElementById('suppartyid').value='<?php echo $suppartyid; ?>'; </script>  
                    </td>
                    
                     
                    <td>&nbsp; <button  type="submit" name="search" class="btn btn-primary" onClick="return checkinputmaster('fromdate');"> Search 
                    </button></td>
                    <td>&nbsp; <a href="salereport.php"  name="reset" id="reset" class="btn btn-success">Reset</a></td>
                    
                    </tr>
                    </table>
                    
                    
                        </form>
                    </div>
                   
                <!--widgetcontent-->
                     
           <p align="right" style="margin-top:7px; margin-right:10px;"> <a href="pdf_sale_report.php?fromdate=<?php echo $fromdate;?>&todate=<?php echo $todate;?>" class="btn btn-info" target="_blank">
                    <span style="font-weight:bold;text-shadow: 2px 2px 2px #000; color:#FFF">Print PDF</span></a></p> 
                <!--widgetcontent-->
                <h4 class="widgettitle"><?php echo $submodule; ?> List</h4>
                
            	<table class="table table-bordered" id="dyntable">
                    <colgroup>
                        <col class="con0" style="align: center; width: 4%" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                    </colgroup>
                    <thead>
               
                         <tr>
                          	<th width="7%" class="head0 nosort">S.No.</th>
                            <th width="16%" class="head0" >Sale No</th>
                             <th width="11%" class="head0">Sale Date</th>
                      
                            <th width="16%" class="head0" >Customer Name</th>
                             <th width="11%" class="head0" >Amount</th>
                             <th width="20%" class="head0">Print Bill</th>
                                               
                        </tr>
                    
                        
                    </thead>
                    <tbody id="record">
                           </span>
                                <?php
									$slno=1;
									$nettot=0;
									//echo "Select * from saleentry $crit order by saleid desc";die;
									
									if($_GET['custtype']=='new' && $_GET['suppartyid']==''){
									$sql_get = mysqli_query($connection,"SELECT `suppartyid`,billno,saleid,saledate,totalsale,disc, count(suppartyid) as totvisit  FROM `saleentry` WHERE `saledate` between '$fromdate' and '$todate' group by suppartyid");
									while($row_get = mysqli_fetch_assoc($sql_get))
									{
									
				if($row_get['totvisit']==1){
				
					//$firsttotmoring++;
				
										
										$total=0;
										$gst=0;
										$suppartyid =$row_get['suppartyid'];
										$disc =$row_get['disc'];
										$totalsale =$row_get['totalsale'];
										$supparty_name = $cmn->getvalfield($connection,"m_supplier_party","supparty_name","suppartyid='$suppartyid'");
										$total = $cmn->getTotalBillAmt($connection,$row_get['saleid']);
										$gst = $cmn->getTotalGst($connection,$row_get['saleid']);
										$igst = $cmn->getTotalIgst_Sale($connection,$row_get['saleid']);
										$total = $total - $disc;
										$nettot+=$totalsale;
										
									   ?> <tr>
                                                <td><?php echo $slno++; ?></td> 
                                                 <td><?php echo $row_get['billno']; ?></td>
                                                <td><?php echo $cmn->dateformatindia($row_get['saledate']); ?></td> 
                                              
                                                 <td><?php echo $supparty_name; ?></td>      
                                                 <td><?php echo number_format(round($totalsale),2);  ?></td>

                                                    <td><a class='btn btn-warning'  href='pdf_sale_details_prnita5.php?saleid=<?php echo  $row_get['saleid'] ; ?>' target="_blank" >Print Bill </a>
													
												</td>
                                               
                        					</tr>
                        <?php
						}}}
						?>
									
							<?php	
									if($_GET['custtype']=='old' && $_GET['suppartyid']==''){
								
									$sql_get = mysqli_query($connection,"SELECT `suppartyid`,billno,saleid,saledate,totalsale,disc, count(suppartyid) as totvisit  FROM `saleentry` WHERE `saledate` between '$fromdate' and '$todate' group by suppartyid");
									while($row_get = mysqli_fetch_assoc($sql_get))
								
						{
								
				if($row_get['totvisit'] > 1){
			
										$total=0;
										$gst=0;
										$suppartyid =$row_get['suppartyid'];
										
										$disc =$row_get['disc'];
									
										$supparty_name = $cmn->getvalfield($connection,"m_supplier_party","supparty_name","suppartyid='$suppartyid'");
									
									
										$newbill='';
										$newsaledate='';
										$newtotsale=0;
										
										$sql= mysqli_query($connection,"Select * from saleentry where saledate between '$fromdate' and '$todate' and suppartyid ='$suppartyid' order by saleid asc");
									
									while($row = mysqli_fetch_assoc($sql))
									{
										$newbill .= $row['billno'].',';
										$newsaledate .= $cmn->dateformatindia($row['saledate']).',';
										$newtotsale += $row['totalsale'];
										
									}
											$nettot+=$newtotsale;
									   ?> <tr>
                                                <td><?php echo $slno++; ?></td> 
                                                 <td><?php echo rtrim($newbill,","); ?></td>
                                                   <td><?php echo rtrim($newsaledate,","); ?></td>
                                              
                                                 <td><?php echo $supparty_name; ?></td>      
                                                 <td><?php echo number_format(round($newtotsale),2);  ?></td>
                                                
                                                    <td></td>
                        					</tr>
                        <?php
						}}}
						?>
							<?php
									if((($_GET['custtype']!='old' && $_GET['custtype']!='new')) && ($_GET['suppartyid']!='' || $fromdate!='')){
									
									$sql_get = mysqli_query($connection,"Select * from saleentry $crit  order by saledate desc,saleid desc");
									
									while($row_get = mysqli_fetch_assoc($sql_get))
									{
										$total=0;
										$gst=0;
										$suppartyid =$row_get['suppartyid'];
										$disc =$row_get['disc'];
										$totalsale =$row_get['totalsale'];
										$supparty_name = $cmn->getvalfield($connection,"m_supplier_party","supparty_name","suppartyid='$suppartyid'");
										$total = $cmn->getTotalBillAmt($connection,$row_get['saleid']);
										$gst = $cmn->getTotalGst($connection,$row_get['saleid']);
										$igst = $cmn->getTotalIgst_Sale($connection,$row_get['saleid']);
										$total = $total - $disc;
										$nettot+=$totalsale;
										
									   ?> <tr>
                                                <td><?php echo $slno++; ?></td> 
                                                 <td><?php echo $row_get['billno']; ?></td>
                                                <td><?php echo $cmn->dateformatindia($row_get['saledate']); ?></td> 
                                               
                                                 <td><?php echo $supparty_name; ?></td>      
                                                 <td><?php echo number_format(round($totalsale),2);  ?></td>
                                                 <td><a class='btn btn-warning'  href='pdf_sale_details_prnita4.php?saleid=<?php echo  $row_get['saleid'] ; ?>' target="_blank" >Print Bill A4</a>&nbsp;
												 <a class='btn btn-primary'  href='pdf_sale_details_prnita5.php?saleid=<?php echo  $row_get['saleid'] ; ?>' target="_blank" >Print Bill A5</a>
												
												</td>
                                               
                        					</tr>
                        <?php
						}}
						?>
                        
                      
                        
                           <thead>
                        <tr style="color:#F00;">
                     
                           
                            <th style="background-color:#FF0;" colspan="4" >&nbsp; </th>
                             <th style="background-color:#FF0;" width="11%" class="head0" ><?php echo number_format(round($nettot),2);?></th>
                               <th style="background-color:#FF0;" ></th>                 
                        </tr>
                    </thead>
                    </tbody>
                </table>
             
                
               
            </div><!--contentinner-->
        </div><!--maincontent-->
        
   
        
    </div>
    <!--mainright-->
    <!-- END OF RIGHT PANEL -->
    
    <div class="clearfix"></div>
     <?php include("inc/footer.php"); ?>
    <!--footer-->

    
</div><!--mainwrapper-->


<script>
	function funDel(id)
	{  //alert(id);   
	

		tblname = '<?php echo $tblname; ?>';
		tblpkey = '<?php echo $tblpkey; ?>';
		pagename = '<?php echo $pagename; ?>';
		submodule = '<?php echo $submodule; ?>';
		module = '<?php echo $module; ?>';
		fromdate = '<?php echo $cmn->dateformatindia($fromdate); ?>';
		todate = '<?php echo $cmn->dateformatindia($todate); ?>';
		// alert(fromdate); 
		if(confirm("Are you sure! You want to delete this record."))
		{
			jQuery.ajax({
			  type: 'POST',
			  url: 'ajax/delete_sale.php',
			  data: 'id='+id+'&tblname='+tblname+'&tblpkey='+tblpkey+'&submodule='+submodule+'&pagename='+pagename+'&module='+module,
			  dataType: 'html',
			  success: function(data){
				  //alert(pagename+'?action=3&fromdate='+fromdate+'&todate='+todate);
				   location=pagename+'?action=3&fromdate='+fromdate+'&todate='+todate;
				}
				
			  });//ajax close
		}//confirm close
	} //fun close

  </script>
    <script>
		
		 jQuery(function() {
                //Datemask dd/mm/yyyy
                jQuery("#fromdate").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
                //Datemask2 mm/dd/yyyy
                jQuery("#todate").inputmask("dd-mm-yyyy", {"placeholder": "mm-dd-yyyy"});
                //Money Euro
                jQuery("[data-mask]").inputmask();
		 });
		</script>

<script> 


function changestatus(saleid,is_completed)
{
var crit="<?php echo $crit; ?>";
	
	//alert(crit);
	if(confirm("Do You want to Update this record ?"))
		{
			jQuery.ajax({
			  type: 'POST',
			  url: 'ajax_update_order.php',
			  data: "saleid="+saleid+'&crit='+crit+'&is_completed='+is_completed,
			  dataType: 'html',
			  success: function(data){
				//alert(data);
				 // jQuery('#record').html(data);
					arr = data.split("|");						
					status =arr[0].trim(); 
					count_product = arr[1].trim();
					
					//alert(status);
					
					if(status==1)
					{
						curr_status="Completed";
					}
					else
					{
						curr_status="Pending";
					}
					
					jQuery('#status'+saleid).html(curr_status);
				 
				}
				
			  });//ajax close
		}//confirm close
}

</script>

</body>

</html>
